#ifndef BUZZER_H
#define BUZZER_H

void init_buzzer();
void tocar_notificacao();
void tocar_som_preenchimento();
void parar_som_preenchimento();
void atualizar_buzzer();

#endif
