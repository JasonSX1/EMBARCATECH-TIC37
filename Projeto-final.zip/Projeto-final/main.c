#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/bootrom.h"
#include "hardware/i2c.h"
#include "hardware/adc.h"
#include "hardware/pwm.h"
#include "inc/ssd1306.h"
#include "inc/font.h"
#include "inc/menu.h"

// Definição dos pinos
#define LED_G 11
#define LED_B 12
#define LED_R 13
#define BUTTON_JOY 22
#define BUTTON_A 5
#define BUTTON_B 6
#define VX_JOY 26
#define VY_JOY 27
#define I2C_PORT i2c1
#define I2C_SDA 14
#define I2C_SCL 15
#define I2C_ADDR 0x3C

#define CENTER 2048  // Valor médio esperado do joystick
#define DEADZONE 300  // Ajuste para melhorar resposta

// Configurações PWM
#define DIVIDER_PWM 100
#define WRAP_PERIOD 20000

// Estrutura do display
ssd1306_t ssd;

// Variáveis globais
static volatile uint32_t last_press_time = 0;
static volatile bool leds_enabled = true;
static int menu_index = 0;


#define MENU_SIZE (sizeof(menu_options) / sizeof(menu_options[0]))

// Configuração de pinos
void setup_gpio(uint pin, bool is_output) {
    gpio_init(pin);
    gpio_set_dir(pin, is_output ? GPIO_OUT : GPIO_IN);
    if (!is_output) gpio_pull_up(pin);
}

void setup_pwm(int pin) {
    uint slice = pwm_gpio_to_slice_num(pin);
    gpio_set_function(pin, GPIO_FUNC_PWM);
    pwm_set_clkdiv(slice, DIVIDER_PWM);
    pwm_set_wrap(slice, WRAP_PERIOD);
    pwm_set_gpio_level(pin, 0);
    pwm_set_enabled(slice, true);
}

// Inicialização do display
bool setup_display() {
    ssd1306_init(&ssd, 128, 64, false, I2C_ADDR, I2C_PORT);
    ssd1306_config(&ssd);
    ssd1306_fill(&ssd, false);
    ssd1306_send_data(&ssd);
    return true;
}

// Atualiza o menu na tela
void draw_menu() {
    ssd1306_fill(&ssd, false);
    for (int i = 0; i < MENU_SIZE; i++) {
        if (i == menu_index) {
            ssd1306_draw_string(&ssd, ">", 0, i * 10);  // Indicador de seleção
        }
        ssd1306_draw_string(&ssd, menu_options[i], 10, i * 10);
    }
    ssd1306_send_data(&ssd);
}

// Função de interrupção para os botões
void button_isr(uint gpio, uint32_t events) {
    uint32_t current_time = to_us_since_boot(get_absolute_time());
    if (current_time - last_press_time < 300000) return;
    last_press_time = current_time;

    if (gpio == BUTTON_A) {
        leds_enabled = !leds_enabled;
    } else if (gpio == BUTTON_B) {
        reset_usb_boot(0, 0);
    }
}

int main() {
    stdio_init_all();
    adc_init();
    adc_gpio_init(VX_JOY);
    adc_gpio_init(VY_JOY);

    // Inicialização do I2C com resistores pull-up
    i2c_init(I2C_PORT, 400 * 1000);
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);

    // Configuração de LEDs e botões
    setup_gpio(LED_G, true);
    setup_gpio(LED_B, true);
    setup_gpio(LED_R, true);
    setup_pwm(LED_B);
    setup_pwm(LED_R);
    setup_gpio(BUTTON_JOY, false);
    setup_gpio(BUTTON_A, false);
    setup_gpio(BUTTON_B, false);

    // Configuração do display
    if (!setup_display()) {
        printf("Falha ao inicializar o display. Encerrando...\n");
        return -1;
    }

    gpio_set_irq_enabled_with_callback(BUTTON_A, GPIO_IRQ_EDGE_FALL, true, button_isr);
    gpio_set_irq_enabled_with_callback(BUTTON_B, GPIO_IRQ_EDGE_FALL, true, button_isr);

    while (true) {
        // Leitura do Joystick para controle do menu
        adc_select_input(1);
        uint16_t x_value = adc_read();
        adc_select_input(0);
        uint16_t y_value = adc_read();

        if (y_value > CENTER + DEADZONE) {
            menu_index = (menu_index + 1) % MENU_SIZE;
        } else if (y_value < CENTER - DEADZONE) {
            menu_index = (menu_index - 1 + MENU_SIZE) % MENU_SIZE;
        }

        draw_menu(); // Atualiza o menu no display

        if (menu_index == 0) {
            // Exibir controle do joystick
            ssd1306_fill(&ssd, false);
            uint x_pos = (x_value * 120) / 4095;
            uint y_pos = 56 - ((y_value * 56) / 4095);
            ssd1306_rect(&ssd, y_pos, x_pos, 8, 8, true, true);
            ssd1306_send_data(&ssd);
        }

        if (menu_index == 1 && leds_enabled) {
            // Controle de LEDs baseado no joystick
            pwm_set_gpio_level(LED_B, 0);
            pwm_set_gpio_level(LED_R, 0);

            if (x_value > CENTER + DEADZONE) { 
                pwm_set_gpio_level(LED_R, ((x_value - CENTER) * WRAP_PERIOD) / (4095 - CENTER));
            } else if (x_value < CENTER - DEADZONE) {  
                pwm_set_gpio_level(LED_R, ((CENTER - x_value) * WRAP_PERIOD) / CENTER);
            } 

            if (y_value > CENTER + DEADZONE) {  
                pwm_set_gpio_level(LED_B, ((y_value - CENTER) * WRAP_PERIOD) / (4095 - CENTER));
            } else if (y_value < CENTER - DEADZONE) {  
                pwm_set_gpio_level(LED_B, ((CENTER - y_value) * WRAP_PERIOD) / CENTER);
            }
        }

        sleep_ms(150);
    }
}
